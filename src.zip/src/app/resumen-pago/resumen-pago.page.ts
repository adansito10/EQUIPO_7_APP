import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resumen-pago',
  templateUrl: './resumen-pago.page.html',
  styleUrls: ['./resumen-pago.page.scss'],
  standalone: false
})
export class ResumenPagoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
